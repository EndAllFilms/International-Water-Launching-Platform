Mod Requirements:

- Off-Shore Launch Platform
- Kerbal Konstructs
- KSRSS (Sorry, I don't do stocks)

Mod Recommendation:

- Starship Expansion Project

- Starship Launch Expansion

Note: If you wanted to contact me, I'd suggest joining my discord server below. If you want to add any suggestions to this mod, I will highly recommend comment it on the forum or join my discord server, it's up to you.

Discord Server: https://discord.gg/UueC5n96TB